import httpx

async def scan_website(url: str) -> dict:
    return {
        "pagespeed": f"Simulated speed check for {url}",
        "tech": "Simulated tech stack: WordPress + jQuery"
    }
