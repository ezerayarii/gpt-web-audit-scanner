from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from app.scanner import scan_website
from app.gpt_engine import generate_report

app = FastAPI()
templates = Jinja2Templates(directory="app/templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("report.html", {"request": request, "report": None})

@app.post("/scan", response_class=HTMLResponse)
async def scan(request: Request, url: str = Form(...)):
    scan_data = await scan_website(url)
    summary = await generate_report(url, scan_data)
    return templates.TemplateResponse("report.html", {
        "request": request,
        "report": summary,
        "url": url
    })
