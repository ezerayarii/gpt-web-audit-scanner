import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

async def generate_report(url: str, data: dict) -> str:
    prompt = f"""
Act as a professional website auditor.

Website: {url}

Scan Data:
- Speed: {data['pagespeed']}
- Tech Stack: {data['tech']}

Give 3 key issues and 1 growth suggestion.
"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content.strip()
