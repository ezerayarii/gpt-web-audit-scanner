# GPT Web Audit Scanner

A lightweight, no-login, AI-powered website scanner that analyzes your site using external APIs and OpenAI GPT.

## Features

- Submit any URL
- Get instant GPT-powered report
- Built with FastAPI
- Dockerized for fast deployment

## Run Locally

```bash
docker build -t scanner-app .
docker run -p 8000:8000 -e OPENAI_API_KEY=your_key scanner-app
```

## Access

Visit: http://localhost:8000
